﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejemplo1
{
    class Program
    {
        static void Main(string[] args)
        {
            Animal alias = new Animal();
            Animal leon = new Leon();

            Console.WriteLine("..............................................." + "\n");
            Console.WriteLine("...............Prueba de interfaces............" + "\n");

            //Instanciamos dos clases del tipo ave pasando de parametro el nombre del ave

            Ave canario = new Ave("Canario");
            Ave cuervo = new Ave("Cuervo");

            //Creamos una instancia de nuestra clase principal para llamar el metodo imprimir()
            Program main = new Program();
            main.imprimir(canario);
            main.imprimir(cuervo);

            
            

            Console.ReadLine();
        }

        public void imprimir(Ave ave)
        {
            //Imprimimos el nombre del ave, el numero de patas y el numero de colas
            Console.WriteLine("Soy un {0} tengo {1} Pata(s), {2} Ala(s) y {3} Cola(s)" + "\n", ave.Nombre, ave.Patas, ave.Alas, ave.Cola);
            //Llamamos a nuestros dos metodos de la interface Comer() y Volar()
            Console.WriteLine("Puedo " + "\n");
            ave.Comer();
            Console.WriteLine("y tambien puedo " + "\n");
            ave.Volar();
        }
    }
}
