﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejemplo1
{
    public class Animal
    {

        public Animal()
        {
            Console.WriteLine("Ha nacido un animal");
        } 

        public virtual void rugir()
        {
            Console.WriteLine("Hace algun ruido");
        }
      
    }
}
