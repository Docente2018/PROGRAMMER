﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejemplo1
{
    interface IAve
    {
        void Volar();
        void Comer();
        
    }
}
