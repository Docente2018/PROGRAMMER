﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejemplo1
{
   public class Leon : Animal
    {

        public Leon()
        {
            Console.WriteLine("Ha nacido un León");
        }
         
        override
        public void rugir()
        {
            Console.WriteLine("ruge el leon");
        }
    }
}
