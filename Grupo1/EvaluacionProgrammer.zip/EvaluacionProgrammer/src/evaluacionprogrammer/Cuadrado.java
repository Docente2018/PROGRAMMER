/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package evaluacionprogrammer;

/**
 *
 * @author jcorremo
 */
public class Cuadrado extends Figura{
    
    private double ladoCuadrado;
    
    public Cuadrado(String nomFigura, double ladoCuadrado) {
        super(nomFigura);
        this.ladoCuadrado = ladoCuadrado;
    }

    @Override
    public double calcularArea() {
        return Math.pow(this.ladoCuadrado, 2);
    }

    @Override
    public double calcularPerim() {
        return 4*this.ladoCuadrado;
    }

    public double getLadoCuadrado() {
        return ladoCuadrado;
    }

    public void setLadoCuadrado(double ladoCuadrado) {
        this.ladoCuadrado = ladoCuadrado;
    }
    
    
}
