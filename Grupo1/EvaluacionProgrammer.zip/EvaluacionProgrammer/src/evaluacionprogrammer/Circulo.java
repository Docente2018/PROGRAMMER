/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package evaluacionprogrammer;

/**
 *
 * @author jcorremo
 */
public class Circulo extends Figura{
    
    private double radioCirc;
    
    public Circulo(String nomFigura,double radioCirc) {
        super(nomFigura);
        this.radioCirc = radioCirc;
    }

    @Override
    public double calcularArea() {
        return Math.PI*Math.pow(this.radioCirc, 2);
    }

    @Override
    public double calcularPerim() {
        return 2*Math.PI*this.radioCirc;
    }

    public double getRadioCirc() {
        return radioCirc;
    }

    public void setRadioCirc(double radioCirc) {
        this.radioCirc = radioCirc;
    }
    
    
}
