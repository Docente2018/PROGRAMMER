/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package evaluacionprogrammer;

/**
 *
 * @author jcorremo
 */
public class Triangulo extends Figura{
    
    private double baseTria;
    private double alturaTria;
    private double ladoA;
    private double ladoB;
    private double ladoC;
    
    public Triangulo(String nomFigura, double baseTria, double alturaTria) {
        super(nomFigura);
        this.alturaTria = alturaTria;
        this.baseTria = baseTria;
    }
    
    public Triangulo(double ladoA, double ladoB, double ladoC, String nomFigura){
        super(nomFigura);
        this.ladoA = ladoA;
        this.ladoB = ladoB;
        this.ladoC = ladoC;
    }

    @Override
    public double calcularArea() {
        return (this.baseTria*this.alturaTria)/2;
    }

    @Override
    public double calcularPerim() {
        return this.ladoA+this.ladoB+this.ladoC;
    }

    public double getBaseTria() {
        return baseTria;
    }

    public void setBaseTria(double baseTria) {
        this.baseTria = baseTria;
    }

    public double getAlturaTria() {
        return alturaTria;
    }

    public void setAlturaTria(double alturaTria) {
        this.alturaTria = alturaTria;
    }

    public double getLadoA() {
        return ladoA;
    }

    public void setLadoA(double ladoA) {
        this.ladoA = ladoA;
    }

    public double getLadoB() {
        return ladoB;
    }

    public void setLadoB(double ladoB) {
        this.ladoB = ladoB;
    }

    public double getLadoC() {
        return ladoC;
    }

    public void setLadoC(double ladoC) {
        this.ladoC = ladoC;
    }
    
    
    
}
