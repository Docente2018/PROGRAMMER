/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package evaluacionprogrammer;

import java.util.Scanner;

/**
 *
 * @author jcorremo
 */
public class EvaluacionProgrammer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Bienvenido!!");
        System.out.println(" presione 1 para crear un Circulo");
        System.out.println(" presione 2 para crear un Cuadrado");
        System.out.println(" presione 3 para crear un Triangulo");
        System.out.println(" presione 4 para crear un Rectangulo");
        switch (sc.nextInt()) {
            case 1:
                Circulo circulo = new Circulo("Circulo", 0);
                System.out.println("Ingrese el radio del circulo");
                circulo.setRadioCirc(sc.nextDouble());
                System.out.println("El perimetro del circulo es " + circulo.calcularPerim());
                System.out.println("El Area del circulo es " + circulo.calcularArea());
                break;
            case 2:
                Cuadrado cuadrado = new Cuadrado("Cuadrado", 0);
                System.out.println("Ingrese el lado del cuadrado");
                cuadrado.setLadoCuadrado(sc.nextDouble());
                System.out.println("El area del cuadrado es " + cuadrado.calcularArea());
                System.out.println("El Perimetro  del cuadrado es " + cuadrado.calcularPerim());
                break;
            case 3:
                Triangulo triangulo = new Triangulo("Triangulo", 0, 0);
                System.out.println("Ingrese la base del Triangulo");
                triangulo.setBaseTria(sc.nextDouble());
                System.out.println("Ingrese la altura del Triangulo");
                triangulo.setAlturaTria(sc.nextDouble());
                System.out.println("Ingrese lado A");
                triangulo.setLadoA(sc.nextDouble());
                System.out.println("Ingrese lado B");
                triangulo.setLadoB(sc.nextDouble());
                System.out.println("Ingrese lado C");
                triangulo.setLadoC(sc.nextDouble());
                System.out.println("El area del Triangulo es " + triangulo.calcularArea());
                System.out.println("El Perimetro  del Triangulo es " + triangulo.calcularPerim());
                break;
            case 4:
                Rectangulo rectangulo = new Rectangulo("Rectangulo", 0, 0);
                System.out.println("Ingrese la base del Rectangulo");
                rectangulo.setBaseRecta(sc.nextDouble());
                System.out.println("Ingrese la altura del Rectangulo");
                rectangulo.setAlturaRecta(sc.nextDouble());
                System.out.println("El area del Triangulo es " + rectangulo.calcularArea());
                System.out.println("El Perimetro  del Triangulo es " + rectangulo.calcularPerim());
                break;
        }
    }

}
