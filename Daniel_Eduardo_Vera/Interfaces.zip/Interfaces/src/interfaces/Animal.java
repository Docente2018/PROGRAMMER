/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces;

/**
 *
 * @author dverapim
 */
public abstract class Animal implements Hablar {

    public abstract void habla();
}

class Perro extends Animal {

    public void habla() {
        System.out.println("El perro hace ¡Guau!");
    }
}

class Gato extends Animal {

    public void habla() {
        System.out.println(" El gato hace ¡Miau!");
    }
}
