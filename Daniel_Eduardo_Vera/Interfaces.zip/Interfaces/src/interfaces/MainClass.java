package interfaces;

/**
 *
 * @author dverapim
 */
public class MainClass {

    /* En la clase Main se crean dos objetos (gato y perro)
    las cuales son utilizadas por la funcion "hacerReuido"
    la cual implementa la interface ""
     */

    public static void main(String[] args) {
        Gato gato = new Gato();
        Perro perro = new Perro();
        hacerRuido(gato);
        hacerRuido(perro);

    }

    static void hacerRuido(Hablar suject) {
        suject.habla();
    }
}
