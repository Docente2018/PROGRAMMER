package interfaces;

/**
 *
 * @author dverapim
 */
public interface Hablar {

    /* se crea un método abstacto "hablar"
    con el fin de implementarlo sobre 
    la clase animal.*/
    public abstract void habla();
}
