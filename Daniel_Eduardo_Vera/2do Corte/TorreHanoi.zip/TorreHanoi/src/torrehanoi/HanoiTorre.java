package torrehanoi;

/**
 *
 * @author ESTUDIANTE
 */
public class HanoiTorre {
    //Método Torres de Hanoi Recursivo

    public static void HanoiTorre(int numero, int origen, int auxiliar, int destino) {
        if (numero == 1) {
            System.out.println("Se mueve el disco de " + origen + " a " + destino);
        } else {
            HanoiTorre(numero - 1, origen, destino, auxiliar);
            System.out.println("se mueve el disco de " + origen + " a " + destino);
            HanoiTorre(numero - 1, auxiliar, origen, destino);
        }
    }

}
