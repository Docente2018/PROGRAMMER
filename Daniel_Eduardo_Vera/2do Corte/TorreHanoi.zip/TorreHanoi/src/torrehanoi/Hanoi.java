/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package torrehanoi;

import java.util.*;
import static torrehanoi.HanoiTorre.HanoiTorre;

public class Hanoi {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in); //Método Scanner para ingresar por teclado
        int numero;
        System.out.println("Numero de discos: ");
        numero = sc.nextInt();//Leer el numero de discos
        HanoiTorre(numero, 1, 2, 3);  //1:origen  2:auxiliar 3:destino
    }
}
